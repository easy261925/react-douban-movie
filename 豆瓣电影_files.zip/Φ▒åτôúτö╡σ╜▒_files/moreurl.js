function moreurl(o,e){var n=["ref="+encodeURIComponent(location.pathname)];for(var r in e)n.push(r+"="+e[r]);set_cookie({report:n.join("&")},1e-4)}
